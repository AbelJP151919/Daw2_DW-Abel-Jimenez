const CuentaM = require('./CuentaM.js');        

        let cuenta = new CuentaM("Carlos", 100);
        cuenta.ingresarDinero();
        cuenta.sacarDinero();
        cuenta.ingresarDinero();
        cuenta.sacarDinero();

